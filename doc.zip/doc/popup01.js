$(function(){
//------------------------------------------------
//$('#popup01 span').on('click', function(){
    //$('#popup01').hide();
//});

$('.popup_close').on('click', function(){
    $(this).parent().hide();
});




//------------------------------------------------
});
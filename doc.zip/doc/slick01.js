$(function(){
//-------------------------
$('.main_slider').slick({
    arrows:false,
    autoplay:true,
    pauseOnHover:false,
    //vertical:true,--아래위로
    fade:true, //흐려졌다 나온다.
});



//--------------------------
})